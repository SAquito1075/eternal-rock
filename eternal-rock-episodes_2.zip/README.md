# Eternal Rock — one page per episode

## Structure

```
index.html                    → homepage: lists every episode, links to its page
equipped-for-war/index.html   → "Equipped for War" episode page (platform buttons)
equipped-for-war/*.webp       → that episode's cover image
_plantilla-episodio/index.html → blank template to copy for the NEXT episode
vercel.json                   → clean URLs config
```

Each episode lives at its own web address, e.g.:

```
eternal-rock.vercel.app/                     → homepage (list of episodes)
eternal-rock.vercel.app/equipped-for-war     → this episode's own page + links
```

Nothing gets overwritten between episodes — every episode keeps its own permanent link, forever.

## Adding a new episode (do this every time you publish one)

**Step 1 — duplicate the template folder.**
Copy `_plantilla-episodio` and rename the copy to a short, URL-friendly slug for the new episode — lowercase, words separated by dashes, no spaces or accents. Example: `faith-over-fear`.

**Step 2 — fill in that folder's `index.html`.**
Inside the new folder, open `index.html` and look for the three `STEP` comments:
- Put the episode's cover image in that same folder, and point `src="tu-portada.webp"` at its real filename.
- Replace `[Episode Title]` (appears 3 times: `<title>`, `og:title`, and the big `<h1 class="mark">`) with the real episode title.
- Fill in the `LINKS` object near the bottom with that episode's Spotify / Apple / Amazon / Castbox / Goodpods / iHeart / Pocket Casts URLs. The social links (Instagram/Facebook/YouTube) already point to the ministry's accounts — leave those as they are.

**Step 3 — add it to the homepage list.**
Open the root `index.html`, find the `EPISODES` array near the bottom, and add one entry at the **top** of the list (newest first):

```js
const EPISODES = [
  {
    title: "Faith Over Fear",
    slug: "faith-over-fear",
    cover: "faith-over-fear/your-cover.webp"
  },
  {
    title: "Equipped for War",
    slug: "equipped-for-war",
    cover: "equipped-for-war/equipped-for-war.webp"
  }
];
```

**Step 4 — publish.** Upload the new folder plus the edited root `index.html` to GitHub (or re-deploy however you're currently publishing). Vercel picks it up automatically if it's connected to your repo.

## A note on URLs

Vercel serves a folder's `index.html` automatically when someone visits that folder's path (e.g. `/equipped-for-war/` shows `equipped-for-war/index.html`), and `cleanUrls` in `vercel.json` lets the trailing slash be optional. I'm confident this is how Vercel's static hosting works, but since I can't test against your live project from here, do one quick check after your first deploy: visit `/equipped-for-war` (no trailing slash) and confirm it loads correctly before you rely on that shorter form in things you share publicly.
